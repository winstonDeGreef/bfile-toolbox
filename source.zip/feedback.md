# giving feedback
You can submit feedback https://github.com/winstonDeGreef/bfile-toolbox/issues (requires a github account) or by sending an email to winstondegreef@gmail.com.