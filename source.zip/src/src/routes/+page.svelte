<script lang="ts">
    import Sequence from "../Sequence.svelte";
    import { SvelteToast } from '@zerodevx/svelte-toast'
</script>

<Sequence />

<style>
    :global(body) {
        font-family: sans-serif;
    }
</style>
<SvelteToast/>