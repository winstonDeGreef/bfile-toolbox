# bfile toolbox
Bfile toolbox is a combination of a browser plugin and a server program that makes creating bfiles for the [oeis](https://oeis.org) easier. In most cases, its enough to paste in the code and pressing run. The code will run and the bfile is added as a file automatically.

## Installation

### Browser plugin
TODO

### program
The server program is just one file: deno/run.ts. To run it, you need to install deno from <https://docs.deno.com/runtime/manual/getting_started/installation>. Afterwards, you need to run the following command in the directory of the file: `deno run -A run.ts` anytime you want to use Bfile Toolbox.

